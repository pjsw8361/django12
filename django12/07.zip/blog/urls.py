app_name='blog'
from django.urls import is_valid_path
from .views import *
urlpatterns = [
    
    ]