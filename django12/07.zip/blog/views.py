from django.shortcuts import render
from django.views.generic.list import ListView
from .models import *
from django.views.generic.detail import DetailView
from django.views.generic.edit import FormView


#제네릭뷰 : 장고에서 제공하는 여러가지 뷰 기능을 수행하는 클래스
#뷰 클래스 구현 시 제네릭뷰를 상속받아 변수/메서드를 수정해 그 기능을 사용할 수 있음
#제네릭뷰를 사용할 때는 문서를 확인하여 어떤 변수/메서드를 수정할 수 있는지 파악해야함

#ListView: 특정 모델클래스의 객체의 목록을 다루는 기능을 수행하는 제네릭뷰
#게시물 목록(index)
class Index(ListView):
    template_name = 'blog/index.html' #HTML 파일의 경로를 저장하는 변수
    model = Post # 목록으로 보여질 model 클래스를 지정하는 변수
    context_object_name = 'post_list' #템플릿에게 객체리스트를 넘겨줄 때 사용할 키 값
    paginate_by = 5 #한 페이지당 보여지는 객체의 개수
    

#DetailView: 특정 모델클래스의 객체 한개를 템플릿에 전달할 때 사용하는 제네릭뷰
#상세페이지(detail)
class Detail(DetailView):
    template_name = 'blog/detail.html'
    model = Post
    context_object_name= 'obj'

#FormView:폼클래스를 객체로 생성해 템플릿으로 넘겨주는 뷰
#글 등록 페이지(postRegister)
class postRegister(FormView):
    template_name = 'blog/postregister.html'
    form_class = ''
    context_object_name = 'form'

    #is_valid()함수가 True를 반환하였을 때에 대한 처리를 form_valid()함수를 오버라이딩해서 구현
    def form_valid(self, form):
        #사용자 입력에 대한 객체 생성 처리
        return FormView.form_valid(self, form)
        
    
    